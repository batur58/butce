// Bütçe Takip — bağımsız uygulama (Firebase Auth + Firestore)
const firebaseConfig = {
  apiKey: "AIzaSyBY1aWcAtBIgFM088TunWyawjMhy1BlvrI",
  authDomain: "butce-takip-5694f.firebaseapp.com",
  projectId: "butce-takip-5694f",
  storageBucket: "butce-takip-5694f.firebasestorage.app",
  messagingSenderId: "829416333826",
  appId: "1:829416333826:web:5c842995a06fd8cb927d1b"
};

const V = "10.14.1";
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = n => "₺" + Math.abs(n).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const sfmt = n => (n < 0 ? "−" : "") + fmt(n);
const low = s => String(s).toLocaleLowerCase("tr");
const num = s => { s = String(s).trim().replace(/\s/g, ""); if (/,\d{1,2}$/.test(s)) s = s.replace(/\./g, "").replace(",", "."); else s = s.replace(/,/g, ""); const v = parseFloat(s); return isFinite(v) ? v : NaN; };
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const ym = d => d.slice(0, 7);
const PAL = ["#0b5d63", "#7a4a8c", "#c07a12", "#b3412a", "#2f6db5", "#a8336b", "#5b7d2a", "#6b7178", "#1f8a70", "#8c5a2b"];
const DEF = {
  cats: {
    exp: [["Market", 0], ["Kira & Fatura", 1], ["Ulaşım", 2], ["Yeme-İçme", 3], ["Sağlık", 4], ["Eğlence", 5], ["Giyim", 6], ["Diğer", 7]].map(([n, i]) => ({ n, c: PAL[i], lim: 0 })),
    inc: [["Maaş", 0], ["Ek gelir", 4], ["Hediye", 5], ["Diğer", 7]].map(([n, i]) => ({ n, c: PAL[i], lim: 0 }))
  }, limit: 0, approval: false, locked: false, note: "", nick: {}, plim: {}, pms: ["Nakit", "Kart", "Havale"]
};

function normCfg(d) {
  d = d && typeof d === "object" ? d : {}; const o = JSON.parse(JSON.stringify(DEF));
  for (const t of ["exp", "inc"]) if (d.cats && Array.isArray(d.cats[t]) && d.cats[t].length) o.cats[t] = d.cats[t].filter(c => c && String(c.n || "").trim()).slice(0, 40).map(c => ({ n: String(c.n).slice(0, 30), c: /^#[0-9a-f]{6}$/i.test(c.c) ? c.c : "#6b7178", lim: Number(c.lim) > 0 ? Number(c.lim) : 0 }));
  o.limit = Number(d.limit) > 0 ? Number(d.limit) : 0; o.approval = !!d.approval; o.locked = !!d.locked; o.note = String(d.note || "").slice(0, 200);
  if (d.nick && typeof d.nick === "object") for (const k in d.nick) o.nick[k] = String(d.nick[k]).slice(0, 30);
  if (d.plim && typeof d.plim === "object") for (const k in d.plim) if (Number(d.plim[k]) > 0) o.plim[k] = Number(d.plim[k]);
  if (Array.isArray(d.pms) && d.pms.length) o.pms = d.pms.map(x => String(x).slice(0, 20)).filter(Boolean).slice(0, 10);
  return o;
}
function normItem(id, d) {
  if (!d || !(Number(d.amt) > 0)) return null;
  return { id, uid: String(d.uid || ""), type: d.type === "inc" ? "inc" : "exp", cat: String(d.cat || "Diğer").slice(0, 30), amt: Math.round(Number(d.amt) * 100) / 100, date: /^\d{4}-\d\d-\d\d$/.test(d.date) ? d.date : today(), note: String(d.note || "").slice(0, 80), pm: String(d.pm || "").slice(0, 20), status: ["ok", "pending", "rejected"].includes(d.status) ? d.status : "ok", ts: Number(d.ts) || 0 };
}

/* ---------- durum ---------- */
let F = {}, auth, db, me = null, gid = null, group = null, cfg = normCfg(null), owner = false;
let items = new Map(), members = {}, type = "exp", cur = today().slice(0, 7), tab = "rec", editId = null, lastDel = null;
let unsub = [];
const show = id => { for (const s of ["splash", "setup", "auth", "onb", "app"]) $(s).hidden = s !== id; };
const catOf = (t, n) => cfg.cats[t].find(c => c.n === n);
const col = (t, n) => (catOf(t, n) || {}).c || "#6b7178";
const who = uid => cfg.nick[uid] || (members[uid] && members[uid].name) || (uid === me?.uid ? "Ben" : "Eski üye");
const all = () => [...items.values()];
const inMonth = (m, arr = all()) => arr.filter(t => ym(t.date) === m);
function sums(arr) { let inc = 0, exp = 0, pend = 0; for (const t of arr) { if (t.status === "ok") { if (t.type === "inc") inc += t.amt; else exp += t.amt; } else if (t.status === "pending" && t.type === "exp") pend += t.amt; } return { inc, exp, pend, bal: inc - exp }; }
function mName(m, s) { const [y, mo] = m.split("-").map(Number); return new Date(y, mo - 1, 1).toLocaleDateString("tr-TR", s ? { month: "short" } : { month: "long", year: "numeric" }); }
function shiftM(m, n) { const [y, mo] = m.split("-").map(Number); const d = new Date(y, mo - 1 + n, 1); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0"); }
const canEditItem = t => owner || (t.uid === me.uid && !cfg.locked && !(cfg.approval && t.status === "ok"));
function errMsg(e) {
  const c = e && e.code || "";
  return ({
    "auth/invalid-credential": "E-posta veya şifre hatalı.", "auth/wrong-password": "E-posta veya şifre hatalı.", "auth/user-not-found": "Bu e-postayla hesap yok.",
    "auth/email-already-in-use": "Bu e-posta zaten kayıtlı. Giriş yapmayı dene.", "auth/weak-password": "Şifre en az 6 karakter olmalı.", "auth/invalid-email": "E-posta adresi geçersiz.",
    "auth/too-many-requests": "Çok fazla deneme. Biraz bekleyip tekrar dene.", "auth/network-request-failed": "İnternet bağlantısı yok.",
    "permission-denied": "Bu işlem için yetkin yok."
  })[c] || "Bir hata oluştu" + (c ? " (" + c + ")" : "") + ".";
}

/* ---------- açılış ---------- */
async function boot() {
  if (!firebaseConfig || !firebaseConfig.apiKey || String(firebaseConfig.apiKey).includes("BURAYA")) { show("setup"); return; }
  const [appM, authM, fsM] = await Promise.all([
    import(`https://www.gstatic.com/firebasejs/${V}/firebase-app.js`),
    import(`https://www.gstatic.com/firebasejs/${V}/firebase-auth.js`),
    import(`https://www.gstatic.com/firebasejs/${V}/firebase-firestore.js`)
  ]);
  F = { ...authM, ...fsM };
  const app = appM.initializeApp(firebaseConfig);
  auth = authM.initializeAuth(app, { persistence: [authM.indexedDBLocalPersistence, authM.browserLocalPersistence] });
  try { db = fsM.initializeFirestore(app, { localCache: fsM.persistentLocalCache({ tabManager: fsM.persistentMultipleTabManager() }) }); }
  catch (e) { db = fsM.getFirestore(app); }
  authM.onAuthStateChanged(auth, u => { stopAll(); me = u; if (!u) { setAuthMode(false); $("aPass").value = ""; show("auth"); return; } loadUser(); });
}
boot().catch(e => { console.error(e); $("splash").querySelector("p").textContent = "Bağlanılamadı. İnternet bağlantını kontrol edip uygulamayı yeniden aç."; });

function stopAll() { $("cmd").value = ""; $("q").value = ""; editId = null; tab = "rec"; unsub.forEach(f => { try { f(); } catch (e) { } }); unsub = []; items = new Map(); members = {}; group = null; gid = null; owner = false; }

/* ---------- giriş / kayıt ---------- */
let reg = false;
function setAuthMode(r) { reg = r; $("authT").textContent = r ? "Hesap oluştur" : "Giriş yap"; $("authGo").textContent = r ? "Kayıt ol" : "Giriş yap"; $("nameL").hidden = !r; $("aName").required = r; $("authSwitch").textContent = r ? "Zaten hesabın var mı? Giriş yap" : "Hesabın yok mu? Kayıt ol"; $("aPass").autocomplete = r ? "new-password" : "current-password"; $("authErr").hidden = true; }
$("authSwitch").onclick = () => setAuthMode(!reg);
$("authF").addEventListener("submit", async e => {
  e.preventDefault(); const mail = $("aMail").value.trim(), pass = $("aPass").value; $("authGo").disabled = true; $("authErr").hidden = true;
  try {
    if (reg) { const name = $("aName").value.trim(); const c = await F.createUserWithEmailAndPassword(auth, mail, pass); await F.updateProfile(c.user, { displayName: name }); await F.setDoc(F.doc(db, "users", c.user.uid), { name, gid: null }, { merge: true }); }
    else await F.signInWithEmailAndPassword(auth, mail, pass);
  } catch (err) { $("authErr").textContent = errMsg(err); $("authErr").hidden = false; }
  $("authGo").disabled = false;
});
$("forgot").onclick = async () => { const mail = $("aMail").value.trim(); if (!mail) { $("authErr").textContent = "Önce e-posta adresini yaz."; $("authErr").hidden = false; return; } try { await F.sendPasswordResetEmail(auth, mail); $("authErr").textContent = "Şifre sıfırlama bağlantısı e-postana gönderildi."; } catch (err) { $("authErr").textContent = errMsg(err); } $("authErr").hidden = false; };
document.addEventListener("click", e => { if (e.target.closest("[data-logout]")) F.signOut(auth); });

/* ---------- kullanıcı / grup ---------- */
let userDoc = {};
async function loadUser() {
  show("splash");
  try { const s = await F.getDoc(F.doc(db, "users", me.uid)); userDoc = s.exists() ? s.data() : {}; } catch (e) { userDoc = {}; }
  if (!userDoc.name) userDoc.name = me.displayName || (me.email || "").split("@")[0];
  if (userDoc.gid) openGroup(userDoc.gid); else showOnb();
}
function showOnb(msg) { $("onbName").textContent = userDoc.name ? ", " + userDoc.name : ""; $("onbErr").hidden = !msg; $("onbErr").textContent = msg || ""; show("onb"); }
const makeCode = () => { const a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let s = ""; const r = crypto.getRandomValues(new Uint32Array(6)); for (const x of r) s += a[x % a.length]; return s; };

$("createF").addEventListener("submit", async e => {
  e.preventDefault(); const btn = e.submitter || e.target.querySelector("button"); btn.disabled = true;
  try {
    const gRef = F.doc(F.collection(db, "groups")); const code = makeCode(); const b = F.writeBatch(db);
    b.set(gRef, { name: $("gName").value.trim().slice(0, 40), owner: me.uid, code, cfg: JSON.parse(JSON.stringify(DEF)), created: Date.now() });
    b.set(F.doc(db, "codes", code), { gid: gRef.id });
    b.set(F.doc(db, "groups", gRef.id, "members", me.uid), { name: userDoc.name, code, joined: Date.now() });
    b.set(F.doc(db, "users", me.uid), { name: userDoc.name, gid: gRef.id }, { merge: true });
    await b.commit(); openGroup(gRef.id);
  } catch (err) { showOnb(errMsg(err)); }
  btn.disabled = false;
});
$("joinF").addEventListener("submit", async e => {
  e.preventDefault(); const btn = e.submitter || e.target.querySelector("button"); btn.disabled = true;
  const code = $("jCode").value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  try {
    const c = await F.getDoc(F.doc(db, "codes", code)); if (!c.exists()) { showOnb("Bu davet kodu geçersiz. Yöneticiden güncel kodu iste."); btn.disabled = false; return; }
    const g = c.data().gid;
    await F.setDoc(F.doc(db, "groups", g, "members", me.uid), { name: userDoc.name, code, joined: Date.now() });
    await F.setDoc(F.doc(db, "users", me.uid), { name: userDoc.name, gid: g }, { merge: true });
    openGroup(g);
  } catch (err) { showOnb(errMsg(err)); }
  btn.disabled = false;
});

function openGroup(g) {
  gid = g; let first = true;
  unsub.push(F.onSnapshot(F.doc(db, "groups", gid), s => {
    if (!s.exists()) { leaveLocal("Grup silinmiş."); return; }
    group = s.data(); cfg = normCfg(group.cfg); const wasOwner = owner; owner = group.owner === me.uid;
    if (first || wasOwner !== owner) { first = false; startData(); show("app"); showTab(); }
    lastFormSig = ""; render();
  }, err => { leaveLocal(err.code === "permission-denied" ? "Bu gruba erişimin kaldırılmış. Yeni bir davet koduyla katılabilirsin." : errMsg(err)); }));
}
let dataUnsub = [];
function startData() {
  dataUnsub.forEach(f => f()); dataUnsub = []; items = new Map();
  const txCol = F.collection(db, "groups", gid, "tx");
  const onTx = s => { for (const ch of s.docChanges()) { if (ch.type === "removed") items.delete(ch.doc.id); else { const it = normItem(ch.doc.id, ch.doc.data()); if (it) items.set(it.id, it); } } $("off").hidden = !s.metadata.fromCache || navigator.onLine; render(); };
  const onErr = err => toast(errMsg(err));
  if (owner) {
    const cutoff = shiftM(today().slice(0, 7), -24) + "-01";
    dataUnsub.push(F.onSnapshot(F.query(txCol, F.where("date", ">=", cutoff)), { includeMetadataChanges: false }, onTx, onErr));
    dataUnsub.push(F.onSnapshot(F.collection(db, "groups", gid, "members"), s => { members = {}; s.forEach(d => members[d.id] = { name: String(d.data().name || "").slice(0, 40) }); render(); }, onErr));
  } else {
    dataUnsub.push(F.onSnapshot(F.query(txCol, F.where("uid", "==", me.uid)), onTx, onErr));
    members = { [me.uid]: { name: userDoc.name } };
  }
  unsub.push(() => dataUnsub.forEach(f => f()));
}
async function leaveLocal(msg) {
  stopAll();
  try { await F.setDoc(F.doc(db, "users", me.uid), { gid: null }, { merge: true }); } catch (e) { }
  userDoc.gid = null; showOnb(msg);
}

/* ---------- yazma ---------- */
const gRef = () => F.doc(db, "groups", gid);
const txRef = id => F.doc(db, "groups", gid, "tx", id);
let cfgT = 0;
function saveCfg(extra) {
  render(); clearTimeout(cfgT);
  cfgT = setTimeout(() => { F.updateDoc(gRef(), { cfg: JSON.parse(JSON.stringify(cfg)), ...(extra || {}) }).catch(err => toast("Ayar kaydedilemedi: " + errMsg(err))); }, 250);
}
const bodyOf = it => ({ uid: it.uid, type: it.type, cat: it.cat, amt: it.amt, date: it.date, note: it.note, pm: it.pm, status: it.status, ts: it.ts });
async function putItem(it) {
  const prev = items.get(it.id); items.set(it.id, it); render();
  // Çevrimdışıyken yazma yerel olarak kaydedilir ve bağlanınca gönderilir; bu yüzden beklemiyoruz.
  F.setDoc(txRef(it.id), bodyOf(it)).catch(err => { if (prev) items.set(it.id, prev); else items.delete(it.id); render(); toast(errMsg(err)); });
  return true;
}
function delItem(it) { items.delete(it.id); render(); F.deleteDoc(txRef(it.id)).catch(err => { items.set(it.id, it); render(); toast(errMsg(err)); }); }

/* ---------- çizim ---------- */
function render() {
  if (!group) return;
  $("gTitle").textContent = group.name || "Bütçe";
  $("mlabel").textContent = mName(cur);
  $("role").textContent = owner ? "Yönetici" : "Harcayan";
  $("admTab").hidden = !owner; if (!owner && tab === "adm") { tab = "rec"; showTab(); return; }
  const M = inMonth(cur), s = sums(M);
  $("balLbl").textContent = owner ? "Bu ayki ortak bakiye" : "Bu ayki bakiyem";
  $("bal").textContent = sfmt(s.bal); $("inc").textContent = fmt(s.inc); $("exp").textContent = fmt(s.exp);
  $("pendBox").hidden = !s.pend; $("pend").textContent = fmt(s.pend);
  renderBudget(s);
  $("ann").hidden = !cfg.note; $("ann").innerHTML = cfg.note ? "<b>Duyuru:</b> " + esc(cfg.note) : "";
  const pc = all().filter(t => t.status === "pending").length; $("admBdg").hidden = !(owner && pc); $("admBdg").textContent = pc;
  renderForm(); renderList();
  if (tab === "sum") renderSum();
  if (tab === "adm" && owner && !$("p-adm").contains(document.activeElement)) renderAdm();
  if (tab === "me" && !$("p-me").contains(document.activeElement)) renderMe();
}
function renderBudget(s) {
  const myLim = cfg.plim[me.uid] || 0; let lim = cfg.limit, used = s.exp, label = "Aylık limit";
  if (!owner) { lim = myLim; label = "Kişisel limitim"; }
  if (!lim) { $("bud").innerHTML = owner ? `<div>Aylık harcama limiti yok.</div><div style="opacity:.8;font-size:13px">Yönetim sekmesinden veya <b>/limit 20000</b> komutuyla belirle.</div>` : `<div>Sana kişisel harcama limiti tanımlanmadı.</div>`; return; }
  const p = Math.min(100, used / lim * 100), left = lim - used;
  $("bud").innerHTML = `<div class="rw"><span>${label}</span><span class="num">${fmt(lim)}</span></div><div class="bar"><i class="${used > lim ? "over" : ""}" style="width:${p}%"></i></div><div class="rw"><span>${left >= 0 ? "Kalan" : "Aşım"}</span><span class="num">${fmt(left)}</span></div>`;
}
let lastFormSig = "";
function renderForm() {
  const sig = JSON.stringify([type, cfg.cats[type].map(c => c.n), cfg.pms]);
  if (sig !== lastFormSig) {
    lastFormSig = sig; const v = $("cat").value, pv = $("pm").value;
    $("cat").innerHTML = cfg.cats[type].map(c => `<option>${esc(c.n)}</option>`).join(""); if (v && catOf(type, v)) $("cat").value = v;
    $("pm").innerHTML = cfg.pms.map(p => `<option>${esc(p)}</option>`).join(""); if (cfg.pms.includes(pv)) $("pm").value = pv;
  }
  $("tExp").setAttribute("aria-pressed", type === "exp"); $("tInc").setAttribute("aria-pressed", type === "inc");
  const blocked = !owner && cfg.locked;
  $("lockMsg").hidden = !blocked; $("lockMsg").textContent = "Yönetici yeni kayıtları geçici olarak kapattı.";
  for (const el of $("f").querySelectorAll("input,select,button")) el.disabled = blocked;
  const c = catOf(type, $("cat").value); let w = "";
  if (type === "exp" && c && c.lim) { const used = sums(inMonth(cur).filter(t => t.cat === c.n && t.type === "exp")).exp; w = `${esc(c.n)} limiti: ${fmt(used)} / ${fmt(c.lim)}` + (used >= c.lim ? " (aşıldı)" : ""); }
  if (!owner && cfg.approval) w += (w ? " · " : "") + "Kayıtların yönetici onayından sonra toplama eklenir.";
  $("catWarn").hidden = !w; $("catWarn").innerHTML = w;
  $("fTitle").textContent = editId ? "Kaydı düzenle" : "Yeni kayıt"; $("cancelEdit").hidden = !editId; $("save").textContent = editId ? "Güncelle" : "Kaydet";
  const fc = $("fCat"), fv = fc.value; const cats = [...new Set([...cfg.cats.exp, ...cfg.cats.inc].map(c => c.n))];
  fc.innerHTML = `<option value="">Tüm kategoriler</option>` + cats.map(n => `<option>${esc(n)}</option>`).join(""); fc.value = cats.includes(fv) ? fv : "";
  const ids = Object.keys(members), fw = $("fWho"); fw.hidden = !owner || ids.length < 2;
  if (!fw.hidden) { const wv = fw.value; fw.innerHTML = `<option value="">Herkes</option>` + ids.map(u => `<option value="${esc(u)}">${esc(who(u))}</option>`).join(""); fw.value = ids.includes(wv) ? wv : ""; }
}
function itemRow(t, admin) {
  const st = t.status === "pending" ? `<span class="pill p">Onay bekliyor</span>` : t.status === "rejected" ? `<span class="pill r">Reddedildi</span>` : "";
  const sub = [t.cat, t.pm, owner && Object.keys(members).length > 1 || admin ? who(t.uid) : ""].filter(Boolean).map(esc).join(" · ");
  let acts = ""; const k = esc(t.id);
  if (admin) acts = `<button class="ok" data-a="ok" data-k="${k}">Onayla</button><button data-a="rej" data-k="${k}">Reddet</button>`;
  else {
    if (owner && t.status === "pending") acts += `<button class="ok" data-a="ok" data-k="${k}">Onayla</button>`;
    if (canEditItem(t)) acts += `<button data-a="edit" data-k="${k}">Düzenle</button><button data-a="dup" data-k="${k}">Bugün tekrarla</button><button data-a="del" data-k="${k}">Sil</button>`;
  }
  return `<li class="tx"><span class="dot" style="background:${col(t.type, t.cat)}">${esc(t.cat.charAt(0))}</span><div><div class="t">${esc(t.note || t.cat)}${st}</div><div class="s">${sub}${admin ? " · " + esc(t.date) : ""}</div></div><span class="num ${t.type === "exp" ? "neg" : "pos"}">${t.type === "exp" ? "−" : "+"}${fmt(t.amt)}</span>${acts ? `<div class="acts">${acts}</div>` : ""}</li>`;
}
function renderList() {
  const q = low($("q").value.trim()), fc = $("fCat").value, fw = $("fWho").value;
  const L = inMonth(cur).filter(t => (!fc || t.cat === fc) && (!fw || t.uid === fw) && (!q || low(t.cat + " " + t.note + " " + t.pm + " " + who(t.uid)).includes(q))).sort((a, b) => b.date.localeCompare(a.date) || b.ts - a.ts);
  if (!items.size) { $("list").innerHTML = `<div class="empty">Henüz kayıt yok. Formdan ya da üstteki komut çubuğundan ilk kaydını ekle (örn. <b>250 market kahve</b>).</div>`; return; }
  if (!L.length) { $("list").innerHTML = `<div class="empty">${q || fc || fw ? "Filtreyle eşleşen kayıt yok." : "Bu ay için kayıt yok."}</div>`; return; }
  let h = "", last = ""; for (const t of L) { if (t.date !== last) { last = t.date; h += `<li class="day">${esc(new Date(t.date + "T12:00").toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" }))}</li>`; } h += itemRow(t); }
  $("list").innerHTML = `<ul>${h}</ul>`;
}
function hbars(rows, total) {
  if (!rows.length) return `<p class="note">Bu ay veri yok.</p>`; const mx = Math.max(...rows.map(r => r.v), 1);
  return rows.map(r => `<div class="hb"><div class="rw"><span>${esc(r.n)} <span class="m">%${total ? Math.round(r.v / total * 100) : 0}${r.lim ? " · limit " + fmt(r.lim) : ""}</span></span><span class="num${r.lim && r.v > r.lim ? " neg" : ""}">${fmt(r.v)}</span></div><div class="tr"><i style="width:${r.v / mx * 100}%;background:${r.c || "var(--teal)"}"></i></div></div>`).join("");
}
function renderSum() {
  const M = inMonth(cur).filter(t => t.status === "ok"), s = sums(M), prev = sums(inMonth(shiftM(cur, -1)).filter(t => t.status === "ok"));
  const ch = prev.exp ? Math.round((s.exp - prev.exp) / prev.exp * 100) : null;
  const [y, mo] = cur.split("-").map(Number); const dim = new Date(y, mo, 0).getDate(); const isCur = cur === today().slice(0, 7); const dd = isCur ? Number(today().slice(8)) : dim;
  $("kpis").innerHTML = [["Gider", fmt(s.exp), ch === null ? "Geçen ay veri yok" : (ch >= 0 ? "+" : "") + ch + "% geçen aya göre"], ["Gelir", fmt(s.inc), ""], ["Bakiye", sfmt(s.bal), s.inc ? "Gelirin %" + Math.max(0, Math.round(s.bal / s.inc * 100)) + " kaldı" : ""], ["Günlük ortalama", fmt(s.exp / dd), isCur ? "Ay sonu tahmini " + fmt(s.exp / dd * dim) : ""]].map(k => `<div class="card"><span>${k[0]}</span><b class="num">${k[1]}</b><span>${esc(k[2])}</span></div>`).join("");
  const E = M.filter(t => t.type === "exp"); const by = f => { const o = {}; E.forEach(t => o[f(t)] = (o[f(t)] || 0) + t.amt); return Object.entries(o).sort((a, b) => b[1] - a[1]); };
  $("sCat").innerHTML = hbars(by(t => t.cat).map(([n, v]) => ({ n, v, c: col("exp", n), lim: (catOf("exp", n) || {}).lim })), s.exp);
  $("sWhoT").textContent = owner ? "Kişiye göre gider" : "Benim giderim";
  $("sWho").innerHTML = hbars(by(t => t.uid).map(([u, v]) => ({ n: who(u), v, lim: cfg.plim[u] })), s.exp);
  $("sPm").innerHTML = hbars(by(t => t.pm || "Belirtilmedi").map(([n, v]) => ({ n, v })), s.exp);
  const ms = [5, 4, 3, 2, 1, 0].map(i => shiftM(cur, -i)); const vs = ms.map(m => sums(inMonth(m)).exp); const mx = Math.max(...vs, 1);
  $("sMon").innerHTML = ms.map((m, i) => `<div class="${m === cur ? "cur" : ""}"><span class="num" style="font-size:11px">${vs[i] ? (Math.round(vs[i] / 100) / 10).toLocaleString("tr-TR") + "b" : ""}</span><i style="height:${vs[i] / mx * 100}%"></i><span>${esc(mName(m, 1))}</span></div>`).join("");
}
function catRows(t) { return cfg.cats[t].map((c, i) => `<div class="crow"><input type="color" value="${esc(c.c)}" data-ct="${t}" data-i="${i}" data-f="c" aria-label="Renk"><input type="text" value="${esc(c.n)}" data-ct="${t}" data-i="${i}" data-f="n" aria-label="Kategori adı">${t === "exp" ? `<input class="lim" inputmode="decimal" placeholder="Limit ₺" value="${c.lim || ""}" data-ct="${t}" data-i="${i}" data-f="lim" aria-label="Kategori limiti">` : ""}<button class="x" data-del="${t}" data-i="${i}" aria-label="Sil">×</button></div>`).join(""); }
function renderAdm() {
  $("code").textContent = group.code || "——";
  $("aGName").value = group.name || ""; $("aLim").value = cfg.limit || ""; $("aAppr").checked = cfg.approval; $("aLock").checked = cfg.locked; $("aNote").value = cfg.note; $("aPm").value = cfg.pms.join(", ");
  $("aExp").innerHTML = catRows("exp"); $("aInc").innerHTML = catRows("inc");
  const P = all().filter(t => t.status === "pending").sort((a, b) => a.ts - b.ts);
  $("pendCard").hidden = !cfg.approval && !P.length;
  $("pendList").innerHTML = P.length ? `<ul>${P.map(t => itemRow(t, true)).join("")}</ul>` : `<p class="note">Onay bekleyen harcama yok.</p>`;
  const M = inMonth(cur).filter(t => t.status === "ok" && t.type === "exp");
  $("aPeople").innerHTML = Object.keys(members).map(u => { const sp = M.filter(t => t.uid === u).reduce((a, t) => a + t.amt, 0); const self = u === me.uid;
    return `<div style="padding:10px 0;border-bottom:1px solid var(--rule)"><div class="rw"><b>${esc(members[u].name || "İsimsiz")}${self ? " (sen)" : ""}</b><span class="num">${fmt(sp)}</span></div><div class="two" style="margin-top:6px"><label>Takma ad<input value="${esc(cfg.nick[u] || "")}" data-nick="${esc(u)}" maxlength="30"></label><label>Aylık limit ₺<input inputmode="decimal" value="${cfg.plim[u] || ""}" data-plim="${esc(u)}"></label></div>${self ? "" : `<button class="link" data-kick="${esc(u)}">Gruptan çıkar</button>`}</div>`; }).join("") || `<p class="note">Henüz kimse yok. Davet kodunu paylaş.</p>`;
}
function renderMe() {
  $("meName").textContent = userDoc.name || ""; $("meMail").textContent = me.email || ""; $("meNameIn").value = userDoc.name || "";
  $("meGroup").textContent = (group.name || "Grup") + " · " + (owner ? "Yöneticisin" : "Harcayan olarak katıldın");
  $("leave").textContent = owner ? "Grubu sil" : "Gruptan ayrıl";
}

/* ---------- kayıt ekleme ---------- */
function submitEntry(o) {
  if (!owner && cfg.locked) { toast("Şu an kayıt eklenemiyor."); return false; }
  const id = F.doc(F.collection(db, "groups", gid, "tx")).id;
  const it = { id, uid: me.uid, type: o.type, cat: o.cat, amt: Math.round(o.amt * 100) / 100, date: o.date || today(), note: (o.note || "").slice(0, 80), pm: o.pm || cfg.pms[0] || "", status: !owner && cfg.approval ? "pending" : "ok", ts: Date.now() };
  putItem(it); cur = ym(it.date); render();
  const c = catOf("exp", it.cat); let extra = "";
  if (it.type === "exp" && c && c.lim) { const u = sums(inMonth(cur).filter(t => t.cat === c.n && t.type === "exp")).exp; if (u > c.lim) extra = " · " + c.n + " limiti aşıldı!"; }
  toast((it.type === "exp" ? "Gider" : "Gelir") + " eklendi: " + fmt(it.amt) + (it.status === "pending" ? " (onay bekliyor)" : "") + extra);
  return true;
}
$("f").addEventListener("submit", e => {
  e.preventDefault();
  const amt = num($("amt").value); if (!(amt > 0)) { $("amt").focus(); toast("Geçerli bir tutar gir."); return; }
  const o = { type, cat: $("cat").value, amt, date: $("date").value || today(), note: $("note").value.trim(), pm: $("pm").value };
  if (editId) { const old = items.get(editId); if (old) { putItem({ ...old, ...o, amt: Math.round(amt * 100) / 100, status: owner ? old.status : (cfg.approval ? "pending" : "ok") }); toast("Kayıt güncellendi."); } editId = null; $("amt").value = ""; $("note").value = ""; render(); return; }
  if (submitEntry(o)) { $("amt").value = ""; $("note").value = ""; $("amt").focus(); }
});
$("cancelEdit").onclick = () => { editId = null; $("amt").value = ""; $("note").value = ""; render(); };
document.addEventListener("click", e => {
  const b = e.target.closest("[data-a]"); if (!b) return; const t = items.get(b.dataset.k); if (!t) return; const a = b.dataset.a;
  if (a === "del") { lastDel = t; delItem(t); toast("Kayıt silindi.", true); }
  else if (a === "edit") { editId = t.id; type = t.type; tab = "rec"; showTab(); lastFormSig = ""; render(); $("cat").value = t.cat; $("amt").value = String(t.amt).replace(".", ","); $("date").value = t.date; $("note").value = t.note; if (cfg.pms.includes(t.pm)) $("pm").value = t.pm; render(); window.scrollTo({ top: $("f").getBoundingClientRect().top + scrollY - 90, behavior: "smooth" }); }
  else if (a === "dup") submitEntry({ ...t, date: today() });
  else if (a === "ok" || a === "rej") { putItem({ ...t, status: a === "ok" ? "ok" : "rejected" }); toast(a === "ok" ? "Onaylandı." : "Reddedildi."); }
});
$("undo").onclick = () => { if (lastDel) { const t = lastDel; lastDel = null; $("toast").classList.remove("on"); putItem(t); } };

/* ---------- yönetim ---------- */
$("p-adm").addEventListener("change", e => {
  const el = e.target; let extra = null;
  if (el.id === "aGName") { const v = el.value.trim().slice(0, 40); if (!v) { el.value = group.name; return; } extra = { name: v }; }
  else if (el.id === "aLim") { const v = num(el.value); cfg.limit = v > 0 ? v : 0; }
  else if (el.id === "aAppr") cfg.approval = el.checked;
  else if (el.id === "aLock") cfg.locked = el.checked;
  else if (el.id === "aNote") cfg.note = el.value.trim().slice(0, 200);
  else if (el.id === "aPm") { const p = el.value.split(",").map(s => s.trim()).filter(Boolean).slice(0, 10); cfg.pms = p.length ? p : ["Nakit"]; }
  else if (el.dataset.ct) {
    const c = cfg.cats[el.dataset.ct][+el.dataset.i]; if (!c) return; const f = el.dataset.f;
    if (f === "n") { const v = el.value.trim().slice(0, 30); if (!v || cfg.cats[el.dataset.ct].some((x, j) => j !== +el.dataset.i && x.n === v)) { el.value = c.n; toast("Bu ad kullanılamaz."); return; } c.n = v; }
    else if (f === "c") c.c = el.value; else { const v = num(el.value); c.lim = v > 0 ? v : 0; }
  }
  else if (el.dataset.nick !== undefined) { const v = el.value.trim(); if (v) cfg.nick[el.dataset.nick] = v.slice(0, 30); else delete cfg.nick[el.dataset.nick]; }
  else if (el.dataset.plim !== undefined) { const v = num(el.value); if (v > 0) cfg.plim[el.dataset.plim] = v; else delete cfg.plim[el.dataset.plim]; }
  else return;
  saveCfg(extra); toast("Ayar kaydedildi.");
});
$("p-adm").addEventListener("click", async e => {
  const b = e.target.closest("[data-del]");
  if (b) { const t = b.dataset.del; if (cfg.cats[t].length <= 1) { toast("En az bir kategori kalmalı."); return; } const [r] = cfg.cats[t].splice(+b.dataset.i, 1); saveCfg(); renderAdm(); toast(r.n + " silindi. Eski kayıtlar korunur."); return; }
  const k = e.target.closest("[data-kick]");
  if (k) { const u = k.dataset.kick; if (await confirmDlg("Kişiyi çıkar", `${esc(who(u))} gruptan çıkarılsın mı? Eski kayıtları kalır, yeni kayıt giremez.`, "Çıkar")) { try { await F.deleteDoc(F.doc(db, "groups", gid, "members", u)); toast("Kişi çıkarıldı."); } catch (err) { toast(errMsg(err)); } } }
});
function addCat(t, n, lim) { n = String(n || "").trim().slice(0, 30); if (!n) { toast("Kategori adı gir."); return false; } if (cfg.cats[t].some(c => low(c.n) === low(n))) { toast("Bu kategori zaten var."); return false; } cfg.cats[t].push({ n, c: PAL[cfg.cats[t].length % PAL.length], lim: lim > 0 ? lim : 0 }); saveCfg(); return true; }
for (const [btn, t, box] of [["addExp", "exp", "aExp"], ["addInc", "inc", "aInc"]]) $(btn).onclick = () => { let i = 1; while (catOf(t, "Yeni kategori " + i)) i++; if (addCat(t, "Yeni kategori " + i)) { renderAdm(); const ins = $(box).querySelectorAll("input[type=text]"); ins[ins.length - 1].select(); } };
async function newCode() {
  const code = makeCode(), old = group.code; const b = F.writeBatch(db);
  b.set(F.doc(db, "codes", code), { gid }); b.update(gRef(), { code }); if (old) b.delete(F.doc(db, "codes", old));
  try { await b.commit(); toast("Yeni davet kodu: " + code + ". Eski kod artık çalışmaz."); } catch (err) { toast(errMsg(err)); }
}
$("newCode").onclick = newCode;
$("shareCode").onclick = () => share(`${group.name || "Bütçe"} grubuna katıl: uygulamayı aç, kayıt ol ve davet kodunu gir: ${group.code}\n${location.origin.startsWith("http") ? location.origin : ""}`, "Davet kodu kopyalandı.");
async function share(text, okMsg) { try { if (navigator.share) { await navigator.share({ text }); return; } } catch (e) { if (e && e.name === "AbortError") return; } try { await navigator.clipboard.writeText(text); toast(okMsg); } catch (e) { openDlg("Paylaş", `<textarea readonly style="height:120px">${esc(text)}</textarea>`); } }

function csv(arr) { const q = v => '"' + String(v).replace(/"/g, '""') + '"'; return "﻿" + ["Tarih;Kişi;Tür;Kategori;Tutar;Ödeme;Not;Durum"].concat(arr.sort((a, b) => a.date.localeCompare(b.date)).map(t => [t.date, who(t.uid), t.type === "exp" ? "Gider" : "Gelir", t.cat, String(t.amt).replace(".", ","), t.pm, t.note, { ok: "Onaylı", pending: "Bekliyor", rejected: "Reddedildi" }[t.status]].map(q).join(";"))).join("\r\n"); }
async function exportCsv(arr, name) {
  const txt = csv(arr), file = new File([txt], name, { type: "text/csv" });
  try { if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: name }); return; } } catch (e) { if (e && e.name === "AbortError") return; }
  try { const a = document.createElement("a"); a.href = URL.createObjectURL(file); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); toast(arr.length + " kayıt indirildi."); }
  catch (e) { share(txt, "CSV kopyalandı."); }
}
$("csvM").onclick = () => exportCsv(inMonth(cur), `butce-${cur}.csv`);
$("csvA").onclick = () => exportCsv(all(), `butce-tumu-${today()}.csv`);

/* ---------- hesap ---------- */
$("meNameIn").addEventListener("change", async e => {
  const v = e.target.value.trim().slice(0, 40); if (!v) { e.target.value = userDoc.name; return; }
  userDoc.name = v;
  try { await F.updateProfile(me, { displayName: v }); await F.setDoc(F.doc(db, "users", me.uid), { name: v }, { merge: true }); await F.updateDoc(F.doc(db, "groups", gid, "members", me.uid), { name: v }); toast("Adın güncellendi."); } catch (err) { toast(errMsg(err)); }
  renderMe();
});
$("resetPw").onclick = async () => { try { await F.sendPasswordResetEmail(auth, me.email); toast("Şifre sıfırlama e-postası gönderildi."); } catch (err) { toast(errMsg(err)); } };
$("leave").onclick = async () => {
  if (owner) {
    if (!await confirmDlg("Grubu sil", "Grup ve davet kodu silinecek, kimse giriş yapamayacak. Kayıtlar veritabanında kalır ama erişilemez. Emin misin?", "Grubu sil")) return;
    try { const b = F.writeBatch(db); if (group.code) b.delete(F.doc(db, "codes", group.code)); b.delete(gRef()); await b.commit(); } catch (err) { toast(errMsg(err)); return; }
  } else {
    if (!await confirmDlg("Gruptan ayrıl", "Bu gruptan ayrılmak istiyor musun? Tekrar katılmak için davet kodu gerekir.", "Ayrıl")) return;
    try { await F.deleteDoc(F.doc(db, "groups", gid, "members", me.uid)); } catch (err) { }
  }
  leaveLocal("");
};
let deferredPrompt = null;
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferredPrompt = e; $("install").hidden = false; });
$("install").onclick = async () => { if (!deferredPrompt) return; deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt = null; $("install").hidden = true; };

/* ---------- komut çubuğu ---------- */
const CMDS = [
  ["/yardım", "Tüm komutları göster", 0], ["/ay 3", "Belirli aya git (1-12), /ay ileri, /ay geri", 0], ["/ara metin", "Hareketlerde ara", 0], ["/özet", "Özet sekmesini aç", 0],
  ["/limit 20000", "Aylık toplam limiti ayarla (0 = kaldır)", 1], ["/kategori Kahve 1500", "Gider kategorisi ekle, isteğe bağlı limitle", 1], ["/gelirkategori Kira geliri", "Gelir kategorisi ekle", 1], ["/kategorisil Kahve", "Kategoriyi kaldır", 1],
  ["/duyuru metin", "Herkese duyuru göster (boş = kaldır)", 1], ["/kilitle", "Yeni kayıtları kapat", 1], ["/aç", "Yeni kayıtları aç", 1], ["/onay aç", "Harcamalar onayına düşsün (aç/kapat)", 1],
  ["/onaylahepsi", "Bekleyen tüm harcamaları onayla", 1], ["/kod", "Davet kodunu paylaş", 1], ["/yenikod", "Yeni davet kodu üret (eskisi iptal olur)", 1], ["/csv", "Bu ayı CSV olarak dışa aktar", 1], ["/yönetim", "Yönetim sekmesini aç", 1]];
let sugI = -1;
function sugList() { const v = low($("cmd").value.trim()); if (!v.startsWith("/")) return []; const w = v.split(" ")[0]; return CMDS.filter(c => (!c[2] || owner) && low(c[0]).startsWith(w)); }
function drawSug() { const L = sugList(); $("sug").style.display = L.length ? "block" : "none"; $("sug").innerHTML = L.map((c, i) => `<button type="button" data-c="${esc(c[0].split(" ")[0])}" class="${i === sugI ? "on" : ""}"><code>${esc(c[0])}</code><span>${esc(c[1])}</span></button>`).join(""); }
$("cmd").addEventListener("input", () => { sugI = -1; drawSug(); });
$("cmd").addEventListener("blur", () => setTimeout(() => $("sug").style.display = "none", 150));
$("sug").addEventListener("mousedown", e => { const b = e.target.closest("button"); if (!b) return; e.preventDefault(); $("cmd").value = b.dataset.c + " "; $("cmd").focus(); drawSug(); });
$("cmd").addEventListener("keydown", e => {
  const L = sugList();
  if (e.key === "ArrowDown" && L.length) { e.preventDefault(); sugI = (sugI + 1) % L.length; drawSug(); }
  else if (e.key === "ArrowUp" && L.length) { e.preventDefault(); sugI = (sugI - 1 + L.length) % L.length; drawSug(); }
  else if (e.key === "Escape") $("sug").style.display = "none";
  else if (e.key === "Enter") {
    e.preventDefault(); if (sugI >= 0 && L[sugI] && !$("cmd").value.includes(" ")) { $("cmd").value = L[sugI][0].split(" ")[0] + " "; sugI = -1; drawSug(); return; }
    const v = $("cmd").value.trim(); if (!v) return; if (runCmd(v) !== false) { $("cmd").value = ""; $("sug").style.display = "none"; $("cmd").blur(); }
  }
});
const needOwner = () => { if (!owner) { toast("Bu komut yalnızca yönetici içindir."); return true; } return false; };
function runCmd(v) {
  if (!v.startsWith("/")) return quickAdd(v);
  const sp = v.indexOf(" "), c = low(sp < 0 ? v : v.slice(0, sp)), arg = sp < 0 ? "" : v.slice(sp + 1).trim();
  switch (c) {
    case "/yardım": case "/yardim": openDlg("Komutlar", `<p class="note">Hızlı ekleme: <b>250 market kahve</b> · gelir için <b>+5000 maaş</b></p><ul>${CMDS.filter(x => !x[2] || owner).map(x => `<li style="padding:8px 0;border-bottom:1px solid var(--rule)"><code style="font-weight:600;color:var(--teal)">${esc(x[0])}</code><br><span class="note">${esc(x[1])}</span></li>`).join("")}</ul>`); return;
    case "/ay": { const a = low(arg); if (a === "ileri") cur = shiftM(cur, 1); else if (a === "geri") cur = shiftM(cur, -1); else { const n = parseInt(a); if (n >= 1 && n <= 12) cur = cur.slice(0, 4) + "-" + String(n).padStart(2, "0"); else { toast("Örn. /ay 3"); return false; } } render(); return; }
    case "/ara": $("q").value = arg; tab = "rec"; showTab(); return;
    case "/özet": case "/ozet": tab = "sum"; showTab(); return;
    case "/yönetim": case "/yonetim": if (needOwner()) return false; tab = "adm"; showTab(); return;
    case "/limit": { if (needOwner()) return false; const n = num(arg); if (!(n >= 0)) { toast("Örn. /limit 20000"); return false; } cfg.limit = n; saveCfg(); toast(n ? "Aylık limit " + fmt(n) + " oldu." : "Limit kaldırıldı."); return; }
    case "/kategori": case "/gelirkategori": { if (needOwner()) return false; const m = arg.match(/^(.*?)(?:\s+([\d.,]+))?$/); if (addCat(c === "/kategori" ? "exp" : "inc", m && m[1], m && m[2] ? num(m[2]) : 0)) { toast((m[1] || "").trim() + " eklendi."); return; } return false; }
    case "/kategorisil": { if (needOwner()) return false; for (const t of ["exp", "inc"]) { const i = cfg.cats[t].findIndex(x => low(x.n) === low(arg)); if (i >= 0) { if (cfg.cats[t].length <= 1) { toast("En az bir kategori kalmalı."); return false; } cfg.cats[t].splice(i, 1); saveCfg(); toast(arg + " silindi."); return; } } toast("Kategori bulunamadı."); return false; }
    case "/duyuru": if (needOwner()) return false; cfg.note = arg.slice(0, 200); saveCfg(); toast(arg ? "Duyuru yayında." : "Duyuru kaldırıldı."); return;
    case "/kilitle": if (needOwner()) return false; cfg.locked = true; saveCfg(); toast("Yeni kayıtlar kilitlendi."); return;
    case "/aç": case "/ac": if (needOwner()) return false; cfg.locked = false; saveCfg(); toast("Kayıtlar açıldı."); return;
    case "/onay": { if (needOwner()) return false; const a = low(arg); cfg.approval = a === "aç" || a === "ac" ? true : a === "kapat" ? false : !cfg.approval; saveCfg(); toast("Onay sistemi " + (cfg.approval ? "açık." : "kapalı.")); return; }
    case "/onaylahepsi": { if (needOwner()) return false; const P = all().filter(t => t.status === "pending"); P.forEach(t => putItem({ ...t, status: "ok" })); toast(P.length + " harcama onaylandı."); return; }
    case "/kod": if (needOwner()) return false; $("shareCode").click(); return;
    case "/yenikod": if (needOwner()) return false; newCode(); return;
    case "/csv": if (needOwner()) return false; exportCsv(inMonth(cur), `butce-${cur}.csv`); return;
  }
  toast("Bilinmeyen komut. /yardım yaz."); return false;
}
function quickAdd(v) {
  let t = "exp"; v = v.replace(/^\+\s*/, () => { t = "inc"; return ""; });
  const m = v.match(/^(\d[\d.,]*)\s*(?:tl|₺)?\s*(.*)$/i); if (!m) { toast("Örn. 250 market kahve · komutlar için /yardım"); return false; }
  const amt = num(m[1]); if (!(amt > 0)) { toast("Geçerli bir tutar gir."); return false; }
  let rest = m[2].trim(), cat; const words = rest.split(/\s+/).filter(Boolean);
  const tryCat = tt => { for (let n = Math.min(3, words.length); n >= 1; n--) { const p = low(words.slice(0, n).join(" ")); const c = cfg.cats[tt].find(x => low(x.n) === p || (low(x.n).startsWith(p) && p.length >= 3)); if (c) return [c, n]; } return null; };
  let r = tryCat(t); if (!r && t === "exp") { const r2 = tryCat("inc"); if (r2) { t = "inc"; r = r2; } }
  if (r) { cat = r[0].n; rest = words.slice(r[1]).join(" "); } else cat = (cfg.cats[t].find(x => low(x.n) === "diğer") || cfg.cats[t][0]).n;
  return submitEntry({ type: t, cat, amt, note: rest, date: today(), pm: cfg.pms[0] }) ? undefined : false;
}

/* ---------- arayüz ---------- */
function showTab() { for (const b of document.querySelectorAll("[data-t]")) b.setAttribute("aria-selected", b.dataset.t === tab); for (const p of ["rec", "sum", "adm", "me"]) $("p-" + p).classList.toggle("on", p === tab); render(); }
for (const b of document.querySelectorAll("[data-t]")) b.onclick = () => { tab = b.dataset.t; showTab(); };
$("tExp").onclick = () => { type = "exp"; render(); }; $("tInc").onclick = () => { type = "inc"; render(); }; $("cat").onchange = render;
$("prev").onclick = () => { cur = shiftM(cur, -1); render(); }; $("next").onclick = () => { cur = shiftM(cur, 1); render(); };
$("q").oninput = renderList; $("fCat").onchange = renderList; $("fWho").onchange = renderList;
function toast(msg, undo) { $("tmsg").textContent = msg; $("undo").style.display = undo ? "" : "none"; $("toast").classList.add("on"); clearTimeout(toast.t); toast.t = setTimeout(() => $("toast").classList.remove("on"), 4500); }
function openDlg(t, h, btns) { $("dT").textContent = t; $("dB").innerHTML = h; $("dBtns").innerHTML = btns || `<button class="ghost" data-close>Kapat</button>`; try { $("dlg").showModal(); } catch (e) { } }
function confirmDlg(t, h, yes) { return new Promise(res => { openDlg(t, `<p>${h}</p>`, `<button class="ghost" data-r="0">Vazgeç</button><button class="go" data-r="1">${esc(yes)}</button>`); $("dBtns").onclick = e => { const b = e.target.closest("[data-r]"); if (!b) return; $("dlg").close(); $("dBtns").onclick = null; res(b.dataset.r === "1"); }; }); }
$("dlg").addEventListener("click", e => { if (e.target.closest("[data-close]")) $("dlg").close(); });
window.addEventListener("online", () => $("off").hidden = true); window.addEventListener("offline", () => $("off").hidden = false);
$("date").value = today();
if ("serviceWorker" in navigator && location.protocol === "https:") navigator.serviceWorker.register("sw.js").catch(() => { });
